/**
 * 홈 페이지 콘텐츠 데이터
 * 섹션별 텍스트 및 구조화된 콘텐츠 중앙 관리
 */

// --- 타입 정의 ---

export type BrandStoryScene = {
  id: number;
  title: string;
  ko: string;
  en: string;
  bg: string;
};

export type MessageBubble = {
  id: number;
  text: string;
};

export type AboutContent = {
  wordPool: string[];
  coreWords: string[];
  sentences: string[];
};

export type FooterColumn = {
  title: string;
  links: { label: string; href: string }[];
};

export type NavLink = {
  label: string;
  href: string;
};

export type HomeContent = {
  hero: {
    slogan: [string, string];
    brandName: string;
    navLinks: NavLink[];
    phrases: [string, string, string];
    bigTypo: { nemo: string; off: string; on: string };
  };
  brandStory: BrandStoryScene[];
  message: {
    bubbles: MessageBubble[];
    serviceFlow: string[];
  };
  about: AboutContent;
  footer: FooterColumn[];
};

// --- 단어비 풀 (250개 랜덤 - 불안/막막함/혼란 등) ---
const WORD_POOL = [
  '불안', '막막함', '혼란', '애매함', '흐릿함', '어색함', '딱딱함', '미묘함',
  '어렵다', '복잡하다', '난해하다', '애매하다', '모호하다', '희미하다', '뿌옇다',
  '정체성', '정체', '혼돈', '무질서', '분산', '산만', '불명확', '불투명',
  '가려짐', '덮임', '숨김', '감춤', '흐려짐', '잊힘', '지워짐', '사라짐',
  '흔들림', '불안정', '변동', '변화', '이동', '회전', '굴곡', '굽이',
  '갈등', '충돌', '대립', '반목', '어긋남', '틀어짐', '비틀림', '꼬임',
  '의문', '질문', '호기심', '궁금함', '의아함', '낯섦', '생소함', '낯설음',
  '피로', '지침', '무기력', '권태', '따분함', '지루함', '번아웃', '탈진',
  '걱정', '염려', '우려', '불안', '초조', '조마조마', '불편', '거북',
  '압박', '강요', '밀림', '쫓김', '몰림', '밀림', '뒤집힘', '뒤죽박죽',
  '흐트러짐', '무너짐', '흐려짐', '녹아남', '섞임', '뒤섞임', '얽힘', '엉킴',
  '단절', '끊김', '잘림', '틈', '간격', '차이', '격차', '괴리',
  '이질감', '어색함', '부자연', '부조화', '불균형', '기울어짐', '휘어짐', '휘감',
  '가림', '덮음', '씌움', '덮어씀', '잊어버림', '잃어버림', '놓침', '흘림',
  '흐름', '흘러감', '밀려남', '떠내려감', '빠져나감', '새어나감', '번져나감', '퍼져나감',
  '닫힘', '막힘', '막다름', '막다른', '끝', '한계', '경계', '테두리',
  '안개', '연기', '먼지', '먼지낀', '흐릿한', '뿌옇게', '어둑한', '어두운',
  '얇은', '가는', '가는실', '실끈', '실마리', '단서', '실타래', '꾸러미',
  '묶음', '묶인', '짓눌린', '누른', '밀린', '쌓인', '쌓아올린', '둘러싼',
  '에워싼', '감싼', '감긴', '감김', '휘감긴', '얽혀진', '엉켜진', '뒤얽힌',
  '흩어진', '뿔뿔이', '사방으로', '여기저기', '이곳저곳', '여기저기', '곳곳이', '산산이',
  '조각', '파편', '조각난', '부서진', '깨어진', '쪼개진', '갈라진', '쪼갠',
  '나뉜', '나눠진', '갈라진', '분리된', '떨어져', '분리되어', '독립된', '고립된',
  '홀로', '혼자', '단독', '단독으로', '각각', '각자', '따로', '따로따로',
  '얽힌', '엉킨', '꼬인', '휘감긴', '감긴', '감싼', '쌌', '둘러쌌',
  '흐른', '흘러간', '지나간', '지나친', '넘어선', '넘은', '건넌', '건너뛴',
  '쏟아진', '쏟아져', '쏟아져서', '쏟아지며', '쏟아져', '쏟아져', '쏟아져', '쏟아져',
  '숨은', '숨겨진', '감춰진', '가려진', '덮인', '씌워진', '덮어씌워진', '가림',
  '비친', '비쳐진', '반사된', '되비친', '되비쳐', '비춰진', '비춰져', '비춰',
  '번졌다', '번져', '퍼졌다', '퍼져', '퍼지며', '퍼져나가', '번져나가', '넓어져',
  '좁아진', '줄어든', '줄어들어', '줄어들며', '줄어', '줄어들', '좁혀진', '좁아',
  '넓어진', '넓어져', '넓혀진', '넓혀져', '퍼진', '퍼져', '번진', '번져',
  '어두워진', '어두워져', '어두워지며', '어두워', '어둡게', '어둡게', '어둑하게', '어둑해',
  '밝아진', '밝아져', '밝아지며', '밝아', '밝게', '밝게', '환하게', '환해',
  '희미해진', '희미해져', '희미해지며', '희미해', '희미하게', '희미하게', '흐릿하게', '흐릿해',
  '선명해진', '선명해져', '선명해지며', '선명해', '선명하게', '선명하게', '뚜렷하게', '뚜렷해',
  '흐려진', '흐려져', '흐려지며', '흐려', '흐리게', '흐리게', '뿌옇게', '뿌옇게',
  '뚜렷해진', '뚜렷해져', '뚜렷해지며', '뚜렷해', '뚜렷하게', '뚜렷하게', '명확하게', '명확해',
];

// --- 홈 페이지 콘텐츠 ---
export const homeContent: HomeContent = {
  hero: {
    slogan: ['불안을 끄고', '기준을 켭니다'],
    brandName: '네모:ON',
    navLinks: [
      { label: '브랜딩', href: '#' },
      { label: '아이덴티티', href: '#' },
      { label: '웹개발', href: '#' },
      { label: '쇼케이스', href: '#' },
      { label: '진단', href: '#' },
      { label: '컨택', href: '#' },
    ],
    phrases: ['감성위에', '구조를 더해', '당신의 결로'],
    bigTypo: { nemo: '네모', off: 'OFF', on: 'ON' },
  },

  brandStory: [
    {
      id: 1,
      title: '네모',
      ko: '사각형·질서·구조',
      en: 'Rectangle · Order · Structure',
      bg: '#f7f1e9',
    },
    {
      id: 2,
      title: 'RECTANGLE',
      ko: '네모의 영문',
      en: 'Right angle · Correct angle',
      bg: '#0B0F12',
    },
    {
      id: 3,
      title: 'REC + ANGLE',
      ko: '기록하다 + 각도',
      en: 'Record + Angle',
      bg: '#f7f1e9',
    },
    {
      id: 4,
      title: '결을 담다',
      ko: '브랜드의 본질',
      en: 'The grain of emotion · structure · you',
      bg: '#0891b2',
    },
    {
      id: 5,
      title: '결을 닮다',
      ko: '당신과 함께',
      en: 'Resemble the grain → Turn on together',
      bg: '#E8734A',
    },
    {
      id: 6,
      title: '네모:ON',
      ko: '불안을 끄고, 기준을 켭니다',
      en: 'Turn off anxiety, turn on standards',
      bg: '#0B0F12',
    },
  ],

  message: {
    bubbles: [
      {
        id: 1,
        text: '우리는 단순히 예쁜 웹사이트를 만들지 않습니다.',
      },
      {
        id: 2,
        text: '당신의 언어를 고객의 언어로, 당신의 생각을 고객의 공감으로, 당신의 가치를 고객의 선택 이유로 번역합니다.',
      },
      {
        id: 3,
        text: '로고·브랜딩·웹으로 당신의 결을 시각화합니다.',
      },
      {
        id: 4,
        text: '브랜딩 → 디자인시스템 → 로고·웹/앱 → 자동화',
      },
    ],
    serviceFlow: ['브랜딩', '디자인시스템', '로고·웹/앱', '자동화'],
  },

  about: {
    wordPool: WORD_POOL,
    coreWords: ['의미', '선명', '설명', '연결'],
    sentences: [
      '당신의 _____를 고객이 이해할 수 있게.',
      '_____한 방향으로 정리합니다.',
      '복잡함을 _____으로 풀어냅니다.',
      '당신과 고객을 _____합니다.',
    ],
  },

  footer: [
    {
      title: '서비스',
      links: [
        { label: '브랜딩', href: '/services/branding' },
        { label: '디자인시스템', href: '/services/design-system' },
        { label: '로고·웹/앱', href: '/services/logo-web' },
        { label: '자동화', href: '/services/automation' },
      ],
    },
    {
      title: '회사',
      links: [
        { label: '소개', href: '/about' },
        { label: '팀', href: '/team' },
        { label: '채용', href: '/careers' },
        { label: '문의', href: '/contact' },
      ],
    },
    {
      title: '리소스',
      links: [
        { label: '블로그', href: '/blog' },
        { label: '케이스스터디', href: '/case-studies' },
        { label: '개인정보처리방침', href: '/privacy' },
        { label: '이용약관', href: '/terms' },
      ],
    },
  ],
};
