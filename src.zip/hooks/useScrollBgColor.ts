'use client';

import { useCallback, useState } from 'react';

export type ColorStop = {
  progress: number; // 0~1
  color: string; // hex
};

/**
 * 스크롤 progress에 따른 배경색 보간 훅
 * colorStops 구간별 hex 색상을 lerp로 보간하여 배경색 반환
 *
 * @param colorStops - [{ progress, color }] 구간 배열
 * @returns { bgColor, onProgress } - 배경색과 progress 콜백
 *
 * Example usage:
 * const { bgColor, onProgress } = useScrollBgColor(colorStops);
 * <div style={{ backgroundColor: bgColor }} />
 * <FreeHorizontalScrollSection onProgress={onProgress} />
 */
export function useScrollBgColor(colorStops: ColorStop[]): {
  bgColor: string;
  onProgress: (progress: number) => void;
} {
  const defaultColor = colorStops[0]?.color ?? '#f7f1e9';
  const [bgColor, setBgColor] = useState<string>(defaultColor);

  const interpolateColor = useCallback((c1: string, c2: string, t: number): string => {
    const parse = (hex: string): [number, number, number] => {
      const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      return r
        ? [parseInt(r[1], 16), parseInt(r[2], 16), parseInt(r[3], 16)]
        : [255, 255, 255];
    };
    const [r1, g1, b1] = parse(c1);
    const [r2, g2, b2] = parse(c2);
    return `rgb(${Math.round(r1 + (r2 - r1) * t)},${Math.round(g1 + (g2 - g1) * t)},${Math.round(b1 + (b2 - b1) * t)})`;
  }, []);

  const onProgress = useCallback(
    (progress: number) => {
      const stops = colorStops;
      if (stops.length < 2) return;

      if (progress >= stops[stops.length - 1].progress) {
        setBgColor(stops[stops.length - 1].color);
        return;
      }

      for (let i = 0; i < stops.length - 1; i++) {
        if (progress >= stops[i].progress && progress < stops[i + 1].progress) {
          const span = stops[i + 1].progress - stops[i].progress;
          const local = (progress - stops[i].progress) / span;
          setBgColor(interpolateColor(stops[i].color, stops[i + 1].color, local));
          return;
        }
      }
    },
    [colorStops, interpolateColor]
  );

  return { bgColor, onProgress };
}
