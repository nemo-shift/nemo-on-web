"use client";

import { useEffect, useRef } from "react";
import Lenis from "lenis";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

type UseLenisScrollOptions = {
  /** GSAP ScrollTrigger와 통합 여부 [기본값: false] */
  integrateGSAP?: boolean;
  /** Lenis duration (초) */
  duration?: number;
  /** 터치 스크롤 배수 [기본값: 2] */
  touchMultiplier?: number;
  /** 마우스 휠 부드럽게 처리 */
  smoothWheel?: boolean;
  /** 터치 부드럽게 처리 (syncTouch) */
  syncTouch?: boolean;
  /** 휠 스크롤 배수 */
  wheelMultiplier?: number;
  /** 스크롤 방향 */
  orientation?: "vertical" | "horizontal";
  /** 제스처 방향 */
  gestureOrientation?: "vertical" | "horizontal" | "both";
  [key: string]: unknown;
};

/**
 * Lenis 부드러운 스크롤 + GSAP ScrollTrigger 통합 훅
 *
 * Lenis 공식 권장 패턴:
 * - GSAP ticker로 lenis.raf() 구동 (RAF 이중 실행 방지)
 * - lenis.on('scroll', ScrollTrigger.update)로 ScrollTrigger 동기화
 * - scrollerProxy 없이 window 스크롤 그대로 사용
 *
 * scrollerProxy를 쓰지 않는 이유:
 * Lenis는 실제 window.scrollY를 움직이기 때문에
 * scrollerProxy로 가상 scroll을 만들 필요가 없음.
 * scrollerProxy를 쓰면 오히려 ScrollTrigger가
 * scroll position을 두 번 계산해서 충돌 발생.
 */
export default function useLenisScroll(
  enabled = true,
  options: UseLenisScrollOptions = {},
): React.MutableRefObject<Lenis | null> {
  const lenisRef = useRef<Lenis | null>(null);

  const {
    integrateGSAP = false,
    touchMultiplier = 2,
    duration = 1.2,
    smoothWheel = true,
    syncTouch = true,
    wheelMultiplier = 1,
    orientation = "vertical",
    gestureOrientation,
    ...lenisOptions
  } = options;

  useEffect(() => {
    if (!enabled || typeof window === "undefined") {
      if (lenisRef.current) {
        lenisRef.current.destroy();
        if (window.lenis === lenisRef.current) window.lenis = null;
        lenisRef.current = null;
      }
      return;
    }

    const lenis = new Lenis({
      duration,
      smoothWheel,
      syncTouch,
      touchMultiplier,
      wheelMultiplier,
      orientation,
      gestureOrientation: gestureOrientation ?? orientation,
      ...lenisOptions,
    });

    lenisRef.current = lenis;
    window.lenis = lenis;

    let unsubscribe: (() => void) | null = null;
    let tickerHandler: ((time: number) => void) | null = null;

    if (integrateGSAP) {
      // Lenis scroll → ScrollTrigger 동기화
      unsubscribe = lenis.on("scroll", ScrollTrigger.update);

      // GSAP ticker로 lenis.raf() 구동
      // time은 초 단위이므로 * 1000해서 ms로 변환
      tickerHandler = (time: number) => lenis.raf(time * 1000);
      gsap.ticker.add(tickerHandler);
      gsap.ticker.lagSmoothing(0);
    } else {
      // integrateGSAP=false면 자체 RAF 루프
      const raf = (time: number) => {
        lenis.raf(time);
        requestAnimationFrame(raf);
      };
      requestAnimationFrame(raf);
    }

    return () => {
      if (unsubscribe) unsubscribe();
      if (tickerHandler) gsap.ticker.remove(tickerHandler);
      lenis.destroy();
      if (window.lenis === lenis) window.lenis = null;
      lenisRef.current = null;
    };
  }, [
    enabled,
    integrateGSAP,
    duration,
    touchMultiplier,
    smoothWheel,
    syncTouch,
    wheelMultiplier,
    orientation,
    gestureOrientation,
    // eslint-disable-next-line react-hooks/exhaustive-deps
    JSON.stringify(lenisOptions),
  ]);

  return lenisRef;
}
