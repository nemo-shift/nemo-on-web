"use client";

import React, { useEffect, useState } from "react";
import { homeContent } from "@/data/homeContent";
import PhraseLine from "./PhraseLine";

type HeroPhraseLayerProps = {
  isOn: boolean;
  visible?: boolean;
  isMobile?: boolean;
  sequenceStep?: number;
  onCopyVisible?: () => void;
};

/**
 * HeroPhraseLayer — 프레이즈 3줄 (도형 포함)
 * 줄1: ○ 감성위에 / 줄2: 구조 △를 더해 / 줄3: 당신의 □로
 */
export default function HeroPhraseLayer({
  isOn,
  visible = true,
  isMobile = false,
  sequenceStep = 0,
  onCopyVisible,
}: HeroPhraseLayerProps): React.ReactElement {
  const { phrases } = homeContent.hero;
  
  // sequenceStep에 따라 각 줄의 가시성 결정
  const lineVisible = [
    sequenceStep >= 1,
    sequenceStep >= 2,
    sequenceStep >= 3,
  ];

  const [squareHover, setSquareHover] = useState(false);

  // 메시지 3줄 다 나온 뒤 콜백 실행 (4단계 진입 시)
  useEffect(() => {
    if (!isOn || sequenceStep < 4) return;
    
    const t1 = setTimeout(() => {
      onCopyVisible?.();
    }, 400);
    return () => clearTimeout(t1);
  }, [isOn, sequenceStep, onCopyVisible]);

  const circleColor = isOn ? "#0891b2" : "rgba(196,168,130,.9)";
  const triColor = isOn ? "#0e7490" : "rgba(232,213,176,.9)";
  const squareColor = isOn ? "#0891b2" : "rgba(240,235,227,.75)"; // 결 컬러 명확하게 변경
  const baseColor = isOn ? "rgb(176, 182, 184)" : "rgba(240,235,227,.22)";

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: isMobile ? "flex-start" : "center", // 모바일에서 좌측 정렬
        gap: ".24em",
        transform: isMobile
          ? "translateX(8%) translateY(-5%)" // 오른쪽으로 약간 이동
          : "translateX(-8%) translateY(28%)",
        pointerEvents: "none",
        zIndex: 20,
        visibility: (isOn && visible) ? "visible" : "hidden", // visibility도 visible 상태에 종속
        opacity: visible ? 1 : 0,
        transition: visible ? "opacity 0.4s ease" : "opacity 0s", // 사라질 때는 즉시
      }}
    >
      <div
        style={{
          position: "relative",
          zIndex: 2,
          display: "flex",
          flexDirection: "column",
          alignItems: isMobile ? "flex-start" : "center", // 모바일에서 좌측 정렬
          gap: ".24em",
        }}
      >
        <PhraseLine isMobile={isMobile} visible={lineVisible[0]} baseColor={baseColor}>
          <span style={{ color: circleColor, transition: "color .7s ease" }}>감성</span>
          <span>위에</span>
        </PhraseLine>

        <PhraseLine isMobile={isMobile} visible={lineVisible[1]} baseColor={baseColor}>
          <span style={{ color: triColor, transition: "color .7s ease" }}>구조</span>
          <span>를 더해</span>
        </PhraseLine>

        <PhraseLine isMobile={isMobile} visible={lineVisible[2]} baseColor={baseColor}>
          <span>당신의</span>
          <span
            onMouseEnter={() => setSquareHover(true)}
            onMouseLeave={() => setSquareHover(false)}
            style={{
              display: "inline-flex",
              width: "1.2em",
              height: "1.2em",
              border: "0.04em solid",
              borderRadius: "0.05em",
              borderColor: isOn ? "#0D1A1F" : squareColor,
              background: isOn ? "#0D1A1F" : "transparent",
              color: isOn ? "#FFFFFF" : squareColor,
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              position: "relative",
              overflow: "hidden",
              transition: "background 0.3s ease, color 0.3s ease",
              cursor: "pointer",
            }}
          >
            <span
              style={{ 
                fontFamily: "Noto Serif KR, serif", 
                fontSize: "0.65em", // 0.55em -> 0.65em으로 텍스트 크기 상향
                fontWeight: "bold",
                color: "inherit",
                transition: "color 0.3s ease",
                lineHeight: 1, // 텍스트 중앙 배치 최적화
                marginTop: "-0.05em" // 시각적 중앙 정렬 보정
              }}
            >
              결
            </span>
          </span>
          <span>로</span>
        </PhraseLine>
      </div>
    </div>
  );
}
