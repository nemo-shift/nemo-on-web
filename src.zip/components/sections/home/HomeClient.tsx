'use client';

import React, { useMemo } from 'react';
import { useHeroContext } from '@/context/HeroContext';
import {
  FreeHorizontalScrollSection,
  FullPageSection,
  Footer,
} from '@/components/layout';
import { useScrollBgColor } from '@/hooks';
import HeroSection from './HeroSection';

const COLOR_STOPS = [
  { progress: 0,    color: '#f7f1e9' },
  { progress: 0.22, color: '#f7f1e9' },
  { progress: 0.25, color: '#0B0F12' },
  { progress: 0.29, color: '#0B0F12' },
  { progress: 0.33, color: '#0E1820' },
  { progress: 0.37, color: '#1A3040' },
  { progress: 0.42, color: '#f7f1e9' },
  { progress: 0.5,  color: '#f7f1e9' },
  { progress: 0.75, color: '#f7f1e9' },
  { progress: 1,    color: '#0a0a0a' },
] as const;

export default function HomeClient(): React.ReactElement {
  const { isOn, toggle, isScrollable } = useHeroContext();
  const colorStops = useMemo(
    () => COLOR_STOPS.map((s) => ({ progress: s.progress, color: s.color })),
    []
  );
  const { bgColor, onProgress } = useScrollBgColor(colorStops);

  return (
    <>
      {/* 배경색 레이어 */}
      <div
        style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: bgColor,
          zIndex: -1,
          pointerEvents: 'none',
        }}
      />

      {/* HeroSection은 항상 마운트 유지 — 재마운트 시 애니메이션 리셋 방지 */}
      <div style={{ display: isScrollable ? 'none' : 'block', width: '100vw', height: '100svh' }}>
        <HeroSection isOn={isOn} onToggle={toggle} />
      </div>

      {/* isScrollable=true일 때만 가로스크롤 마운트 */}
      {isScrollable && (
        <FreeHorizontalScrollSection onProgress={onProgress}>
          <FullPageSection widthType="vw">
            <HeroSection isOn={isOn} onToggle={toggle} />
          </FullPageSection>
          <FullPageSection
            widthType="vw"
            className="bg-brand-primary flex items-center justify-center"
          >
            <div className="text-center">
              <h2 className="text-white text-5xl font-bold mb-4">Brand Story</h2>
              <p className="text-white/60 text-xl font-mono uppercase tracking-widest">
                Coming Soon
              </p>
            </div>
          </FullPageSection>
          <FullPageSection
            widthType="vw"
            className="bg-surface-cream flex items-center justify-center"
          >
            <div className="text-center">
              <h2 className="text-text-primary text-5xl font-bold mb-4">Message</h2>
              <p className="text-text-muted text-xl font-mono uppercase tracking-widest">
                Preparing Contents
              </p>
            </div>
          </FullPageSection>
          <FullPageSection widthType="vw" className="justify-end pb-8">
            <Footer />
          </FullPageSection>
        </FreeHorizontalScrollSection>
      )}
    </>
  );
}
