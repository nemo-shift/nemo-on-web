'use client';

import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useMousePosition, useDeviceDetection } from '@/hooks';

type PointRingCursorProps = {
  isOn: boolean; // ON 상태 여부 — 색상 전환에 사용 [Required]
};

/**
 * PointRingCursor 컴포넌트
 *
 * 마우스 커서를 숨기고 커스텀 point + ring 커서를 렌더링한다.
 * - 모바일 뷰포트(768px 미만)에서만 숨김 (PC/터치 PC 모두 데스크탑 뷰에서는 표시)
 * - OFF: point #e8d5b0, ring rgba(196,168,130,.3)
 * - ON: point rgba(8,145,178,.7), ring rgba(8,145,178,.35)
 * - 인터랙티브 요소 hover 시 링이 네모(50×50, border-radius 4px)로 변환
 *
 * @param {boolean} isOn - ON/OFF 상태 [Required]
 *
 * Example usage:
 * <PointRingCursor isOn={isOn} />
 */
export default function PointRingCursor({ isOn }: PointRingCursorProps): React.ReactElement | null {
  const [mounted, setMounted] = useState(false);
  const [isHover, setIsHover] = useState(false);
  const { position } = useMousePosition();
  const { isMobile } = useDeviceDetection();
  const positionRef = useRef(position);
  const pointRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const animRef = useRef<number>(0);
  const isHoverRef = useRef(false);

  positionRef.current = position;
  isHoverRef.current = isHover;

  const showCursor = !isMobile;

  // 클라이언트 마운트 후에만 커서 렌더 (하이드레이션 불일치 방지)
  useEffect(() => {
    setMounted(true);
  }, []);

  // 기본 커서 숨기기 — html에 클래스 부여 (인라인 cursor:pointer 등 덮어쓰기)
  useEffect(() => {
    if (!mounted || !showCursor) return;
    document.documentElement.classList.add('custom-cursor-active');
    return () => {
      document.documentElement.classList.remove('custom-cursor-active');
    };
  }, [mounted, showCursor]);

  // 인터랙티브 요소 호버 시 링 → 네모 변환
  useEffect(() => {
    if (!mounted) return;
    const selectors = 'a, button, [data-cursor="pointer"], .pill, [data-bt], [role="button"]';

    const onEnter = () => setIsHover(true);
    const onLeave = () => setIsHover(false);

    const attach = () => {
      document.querySelectorAll(selectors).forEach((el) => {
        el.addEventListener('mouseenter', onEnter);
        el.addEventListener('mouseleave', onLeave);
      });
    };

    attach();
    const observer = new MutationObserver(attach);
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      document.querySelectorAll(selectors).forEach((el) => {
        el.removeEventListener('mouseenter', onEnter);
        el.removeEventListener('mouseleave', onLeave);
      });
    };
  }, [mounted]);

  // point + ring 부드러운 따라오기 (lerp 애니메이션)
  useEffect(() => {
    let px = 0;
    let py = 0;
    let rx = 0;
    let ry = 0;
    const POINT_LERP = 0.3;
    const RING_LERP = 0.15;

    const animate = () => {
      const { x, y } = positionRef.current;
      px += (x - px) * POINT_LERP;
      py += (y - py) * POINT_LERP;
      rx += (x - rx) * RING_LERP;
      ry += (y - ry) * RING_LERP;

      if (pointRef.current) {
        pointRef.current.style.transform = `translate3d(${px - 4}px, ${py - 4}px, 0)`;
      }
      if (ringRef.current) {
        const size = isHoverRef.current ? 50 : 30;
        const half = size / 2;
        ringRef.current.style.transform = `translate3d(${rx - half}px, ${ry - half}px, 0)`;
      }
      animRef.current = requestAnimationFrame(animate);
    };

    animRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animRef.current);
  }, []);

  // ON/OFF 상태에 따른 색상
  const pointColor = isOn ? 'rgba(8,145,178,.7)' : '#e8d5b0';
  const ringColor = isOn ? 'rgba(8,145,178,.35)' : 'rgba(196,168,130,.3)';
  const squareColor = '#E8734A'; // 네모(호버) 색상

  // document.body에 포탈 — Lenis 등 transform 부모 밖에서 position:fixed가 뷰포트 기준으로 동작
  const cursorContent = (
    <>
      {/* 중심 점 — 8×8, transform으로 마우스 위치에 중심 맞춤 */}
      <div
        ref={pointRef}
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: 8,
          height: 8,
          backgroundColor: pointColor,
          borderRadius: '50%',
          pointerEvents: 'none',
          zIndex: 99999,
          willChange: 'transform',
          transition: 'background-color 0.5s ease',
        }}
      />
      {/* 바깥 링 — 기본 원(30×30), 호버 시 네모(50×50) */}
      <div
        ref={ringRef}
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: isHover ? 50 : 30,
          height: isHover ? 50 : 30,
          border: `1px solid ${isHover ? squareColor : ringColor}`,
          borderRadius: isHover ? '4px' : '50%',
          pointerEvents: 'none',
          zIndex: 99998,
          willChange: 'transform',
          transition: 'width .25s, height .25s, border-radius .25s, border-color .6s ease',
        }}
      />
    </>
  );

  if (!mounted || typeof document === 'undefined' || !showCursor) return null;
  return createPortal(cursorContent, document.body);
}
