"use client";

import React, { useRef, useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { cn } from "@/lib";

gsap.registerPlugin(ScrollTrigger);

type FreeHorizontalScrollSectionProps = {
  children: React.ReactNode;
  className?: string;
  onProgress?: (progress: number) => void;
};

/**
 * FreeHorizontalScrollSection
 *
 * 세로 스크롤을 가로 패널 이동으로 변환하는 컴포넌트.
 * 마운트 시 항상 활성 상태 (잠금/해제는 조건부 마운트로 제어)
 */
export default function FreeHorizontalScrollSection({
  children,
  className,
  onProgress,
}: FreeHorizontalScrollSectionProps): React.ReactElement {
  const sectionRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const onProgressRef = useRef(onProgress);
  onProgressRef.current = onProgress;
  const triggerRef = useRef<ScrollTrigger | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const container = containerRef.current;
    if (!section || !container) return;

    const getMaxX = () =>
      Math.max(0, container.scrollWidth - window.innerWidth);

    gsap.set(container, { display: "flex", flexWrap: "nowrap" });

    const delayed = gsap.delayedCall(0.05, () => {
      triggerRef.current = ScrollTrigger.create({
        trigger: section,
        start: "top top",
        end: () => `+=${getMaxX()}`,
        pin: true,
        scrub: 1,
        invalidateOnRefresh: true,
        onUpdate: (self) => {
          gsap.set(container, { x: -getMaxX() * self.progress });
          onProgressRef.current?.(self.progress);
        },
      });
    });

    return () => {
      delayed.kill();

      // React DOM 정리 전에 ScrollTrigger kill
      if (triggerRef.current) {
        triggerRef.current.kill(true);
        triggerRef.current = null;
      }

      // pin-spacer를 직접 unwrap (removeChild 에러 방지)
      document.querySelectorAll(".gsap-pin-spacer, .pin-spacer").forEach((spacer) => {
        if (spacer.contains(section)) {
          try {
            spacer.replaceWith(section);
          } catch {}
        }
      });

      gsap.set(container, { clearProps: "all" });
    };
  }, []);

  return (
    <div
      ref={sectionRef}
      className={cn("relative w-full overflow-hidden", className)}
      style={{ height: "100svh" }}
    >
      <div
        ref={containerRef}
        className="absolute top-0 left-0 h-full"
        style={{ willChange: "transform" }}
      >
        {React.Children.map(children, (child, i) => (
          <div
            key={i}
            style={{ width: "100vw", height: "100%", flexShrink: 0 }}
            className="flex items-center justify-center"
          >
            {child}
          </div>
        ))}
      </div>
    </div>
  );
}
