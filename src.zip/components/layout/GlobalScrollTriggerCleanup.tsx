"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { ScrollTrigger } from "gsap/ScrollTrigger";

/**
 * GSAP ScrollTrigger 전역 정리 컴포넌트
 * 라우트 변경 시 ScrollTrigger 인스턴스 및 pin-spacer 등 정리
 *
 * Example usage:
 * <GlobalScrollTriggerCleanup />
 */
export default function GlobalScrollTriggerCleanup(): null {
  const pathname = usePathname();

  useEffect(() => {
    if (typeof window === "undefined") return;

    // ✅ 여기(마운트)에선 아무것도 하지 말 것

    return () => {
      // ✅ 페이지 이동/언마운트 시에만 정리
      ScrollTrigger.getAll().forEach((t) => t.kill(true));

      const pinSpacers = document.querySelectorAll(
        ".pin-spacer, .gsap-pin-spacer",
      );
      pinSpacers.forEach((spacer) => spacer.remove());

      // ⚠️ 아래 스타일 삭제는 “정말 필요할 때만” 유지 (가능하면 제거 권장)
      const elementsWithGSAPStyles = document.querySelectorAll(
        '[style*="transform"], [style*="pin"], [style*="position: fixed"]',
      );
      elementsWithGSAPStyles.forEach((element) => {
        const el = element as HTMLElement;
        // transform 전체를 지우면 너의 가로 스크롤 translateX도 날릴 수 있음 → 웬만하면 지우지 마
        // el.style.transform = "";
        if (el.style.position === "fixed") {
          el.style.position = "";
        }
      });
    };
  }, [pathname]);

  return null;
}
