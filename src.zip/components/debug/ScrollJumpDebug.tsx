'use client';

import { useEffect } from 'react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

/**
 * 스크롤 점프 디버거 (개발 전용)
 * - window.scroll 이벤트로 되튐 감지
 * - scrollTo / scrollIntoView 호출 추적
 */
export default function ScrollJumpDebug(): null {
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if ((window as Window & { __SCROLL_JUMP_DEBUG__?: boolean }).__SCROLL_JUMP_DEBUG__) return;
    (window as Window & { __SCROLL_JUMP_DEBUG__?: boolean }).__SCROLL_JUMP_DEBUG__ = true;

    let lastY = window.scrollY;
    let lastT = performance.now();

    const logJump = (tag: string) => {
      const y = window.scrollY;
      const now = performance.now();
      const dy = y - lastY;
      const dt = now - lastT;

      if (dt < 250 && dy < -200) {
        console.groupCollapsed(
          `%c[SCROLL JUMP] ${tag} dy=${dy.toFixed(0)} y:${lastY.toFixed(0)}→${y.toFixed(0)} dt=${dt.toFixed(0)}ms`,
          'color:#ff4d4f;font-weight:bold;'
        );
        console.trace('jump trace');
        console.log('docEl.scrollTop', document.documentElement.scrollTop);
        console.log('body.scrollTop', document.body.scrollTop);
        console.groupEnd();
      }

      lastY = y;
      lastT = now;
    };

    window.addEventListener('scroll', () => logJump('window.scroll'), { passive: true });

    // scrollTop 직접 세팅 감지 (Lenis 등이 documentElement.scrollTop = 0 하는 경우)
    const scrollTopDescriptor =
      Object.getOwnPropertyDescriptor(Element.prototype, "scrollTop") ??
      Object.getOwnPropertyDescriptor(HTMLElement.prototype, "scrollTop");

    let scrollTopRestore: (() => void) | null = null;
    if (scrollTopDescriptor?.set) {
      const originalSet = scrollTopDescriptor.set;
      const docEl = document.documentElement;
      Object.defineProperty(docEl, "scrollTop", {
        set(value: number) {
          console.groupCollapsed(
            "%c[documentElement.scrollTop SET]",
            "color:#ff7875;font-weight:bold;"
          );
          console.log("value:", value, "/ current:", docEl.scrollTop);
          console.trace("trace");
          console.groupEnd();
          originalSet.call(this, value);
        },
        get() {
          return scrollTopDescriptor.get?.call(this) ?? 0;
        },
        configurable: true,
      });
      scrollTopRestore = () => {
        try {
          delete (docEl as unknown as Record<string, unknown>).scrollTop;
        } catch {
          /* restore 실패 시 무시 */
        }
      };
    }

    // scrollTo 훅킹 (가장 중요)
    const _scrollTo = window.scrollTo.bind(window);
    window.scrollTo = ((...args: any[]) => {
      console.groupCollapsed('%c[scrollTo called]', 'color:#ffa940;font-weight:bold;');
      console.log('args', args);
      console.trace('trace');
      console.groupEnd();
      // @ts-ignore
      return _scrollTo(...args);
    }) as any;

    // scroll 훅킹(일부 코드가 scroll()을 쓰는 경우)
    const _scroll = window.scroll.bind(window);
    window.scroll = ((...args: any[]) => {
      console.groupCollapsed('%c[scroll called]', 'color:#ffa940;font-weight:bold;');
      console.log('args', args);
      console.trace('trace');
      console.groupEnd();
      // @ts-ignore
      return _scroll(...args);
    }) as any;

    // Element.scrollTo 훅킹 (컨테이너가 scrollTo로 0으로 리셋되는 경우 잡음)
    const _elScrollTo = Element.prototype.scrollTo;
    Element.prototype.scrollTo = function (...args: any[]) {
      console.groupCollapsed('%c[Element.scrollTo called]', 'color:#ffa940;font-weight:bold;');
      console.log('target', this);
      console.log('args', args);
      console.trace('trace');
      console.groupEnd();
      // @ts-ignore
      return _elScrollTo.apply(this, args);
    };

    // Element.scrollBy 훅킹
    const _elScrollBy = Element.prototype.scrollBy;
    Element.prototype.scrollBy = function (...args: any[]) {
      console.groupCollapsed('%c[Element.scrollBy called]', 'color:#ffa940;font-weight:bold;');
      console.log('target', this);
      console.log('args', args);
      console.trace('trace');
      console.groupEnd();
      // @ts-ignore
      return _elScrollBy.apply(this, args);
    };

    // scrollIntoView 훅킹
    const _siv = Element.prototype.scrollIntoView;
    Element.prototype.scrollIntoView = function (...args: any[]) {
      console.groupCollapsed('%c[scrollIntoView called]', 'color:#ffa940;font-weight:bold;');
      console.log('target', this);
      console.log('args', args);
      console.trace('trace');
      console.groupEnd();
      // @ts-ignore
      return _siv.apply(this, args);
    };

    // hash / history / popstate 원인 추적
    const onHashChange = () => {
      console.groupCollapsed('%c[hashchange]', 'color:#40a9ff;font-weight:bold;');
      console.log('hash', location.hash);
      console.trace('trace');
      console.groupEnd();
    };
    const onPopState = () => {
      console.groupCollapsed('%c[popstate]', 'color:#40a9ff;font-weight:bold;');
      console.log('url', location.href);
      console.trace('trace');
      console.groupEnd();
    };
    window.addEventListener('hashchange', onHashChange);
    window.addEventListener('popstate', onPopState);

    // ScrollTrigger.refresh / revert 호출자 훅킹
    const _stRefresh = ScrollTrigger.refresh.bind(ScrollTrigger);
    ScrollTrigger.refresh = ((...args: any[]) => {
      console.log('%c[ScrollTrigger.refresh called] y=' + window.scrollY, 'color:#2f54eb;font-weight:bold;');
      console.trace('refresh trace');  // ✅ 이 줄이 반드시 실행돼야 함
      return _stRefresh(...args);
    }) as any;

    const _stRevert = (ScrollTrigger as any).revert?.bind(ScrollTrigger);
    if (_stRevert) {
      (ScrollTrigger as any).revert = ((...args: any[]) => {
        console.groupCollapsed('%c[ScrollTrigger.revert called]', 'color:#2f54eb;font-weight:bold;');
        console.log('args', args, 'y', window.scrollY);
        console.trace('trace');
        console.groupEnd();
        return _stRevert(...args);
      }) as any;
    }

    return () => {
      scrollTopRestore?.();
      window.scrollTo = _scrollTo;
      window.scroll = _scroll;
      Element.prototype.scrollTo = _elScrollTo;
      Element.prototype.scrollBy = _elScrollBy;
      Element.prototype.scrollIntoView = _siv;
      ScrollTrigger.refresh = _stRefresh;
      if (_stRevert) (ScrollTrigger as any).revert = _stRevert;
      window.removeEventListener('hashchange', onHashChange);
      window.removeEventListener('popstate', onPopState);
      (window as Window & { __SCROLL_JUMP_DEBUG__?: boolean }).__SCROLL_JUMP_DEBUG__ = false;
    };
  }, []);

  return null;
}